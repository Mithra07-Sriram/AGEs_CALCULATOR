## [1.0.0] - 08/03/2021

Migration to null safety from package [age](https://pub.dev/packages/age) and added test coverage and new apis

